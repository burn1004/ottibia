function onUse(cid, item, frompos, item2, topos)
	if(item2.uid > 65535 and isCreature(item2.uid) == FALSE and isMoveable(item2.uid) == TRUE and item2.actionid == 0) then
CHANCEDICE = math.random(1,100)
if CHANCEDICE <= 33 then
	if item2.itemid == 3794 then
        doTransformItem(item2.uid,3959)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3795 then
        doTransformItem(item2.uid,3959)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3796 then
        doTransformItem(item2.uid,3958)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3797 then
        doTransformItem(item2.uid,3958)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3798 then
        doTransformItem(item2.uid,3958)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3799 then
        doTransformItem(item2.uid,3958)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1615 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1614 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1616 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1619 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1650 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1651 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1652 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1653 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1658 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1659 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1660 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1661 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1666 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1667 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1668 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1669 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1670 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1671 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1672 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1673 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1674 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1675 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1676 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1677 then
        doTransformItem(item2.uid,2253)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1714 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1715 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1716 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1717 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 1724 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1725 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1726 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1727 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 1728 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1729 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1730 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1731 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1732 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1733 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1734 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1735 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1775 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2034 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 4996 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2116 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2117 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2118 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2119 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6123 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2080 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2081 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2082 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2083 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2084 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2085 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2093 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2094 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2095 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2098 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2099 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2101 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2106 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2105 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2562 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2581 then
        doTransformItem(item2.uid,2258)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2582 then
        doTransformItem(item2.uid,2258)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 2583 then
        doTransformItem(item2.uid,2258)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3805 then
        doTransformItem(item2.uid,6267)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3806 then
        doTransformItem(item2.uid,6267)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3807 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3808 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3809 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3810 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3811 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3812 then
        doTransformItem(item2.uid,6267)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3813 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3814 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3815 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3816 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3817 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3818 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3819 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3820 then
        doTransformItem(item2.uid,2252)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3821 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3832 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3833 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3834 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 3835 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6356 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6357 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6358 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6359 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6360 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6361 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6362 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6363 then
        doTransformItem(item2.uid,2257)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6368 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6369 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6370 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6371 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1738 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1739 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1740 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1741 then
        doTransformItem(item2.uid,2255)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1747 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1748 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1749 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1750 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1751 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1752 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1753 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1770 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 1774 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6085 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7481 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 7482 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 7483 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7484 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7706 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7707 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 1738 then
        doTransformItem(item2.uid,2250)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 1739 then
        doTransformItem(item2.uid,2251)
        doSendMagicEffect(topos,2)


    elseif item2.itemid == 6109 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6110 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6111 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 6112 then
        doTransformItem(item2.uid,2254)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7538 then
        doTransformItem(item2.uid,7544)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7539 then
        doTransformItem(item2.uid,7545)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7537 then
        doTransformItem(item2.uid,7536)
        doSummonCreature("Spider", pos)
        doSendMagicEffect(topos,2)

    elseif item2.itemid == 7585 then
        doTransformItem(item2.uid,7586)
        doSummonCreature("Giant Spider", pos)
        doSendMagicEffect(topos,2)
		
	elseif item2.itemid == 3794 or item2.itemid == 3795 or item2.itemid == 3796 or item2.itemid == 3797 or item2.itemid == 3798 or item2.itemid == 3799 then
	doTransformItem(item2.uid, 3959)
		
    else
        return 0
    end
    return 1
else
doSendMagicEffect(topos,2)
end
end	
end