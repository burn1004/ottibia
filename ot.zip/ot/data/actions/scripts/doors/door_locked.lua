function onUse(cid, item, frompos, item2, topos)
	doPlayerSendTextMessage(cid,22,'It is locked.')
	return TRUE
end