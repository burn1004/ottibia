function onUse(cid, item, fromPosition, itemEx, toPosition)
if itemEx.itemid == 1490 or itemEx.itemid == 1490 then
doPlayerAddItem(cid, 2006, 1)
end
return true
end