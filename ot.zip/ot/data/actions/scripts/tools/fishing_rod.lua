function onUse(cid, item, frompos, item2, topos)

            doPlayerSendTextMessage(cid, 22, "To catch a fish you need worms.")
end