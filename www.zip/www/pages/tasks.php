<?php
if(!defined('INITIALIZED'))
	exit;

	$main_content .= '<table border="0" cellpadding="4" cellspacing="1" width="95%">
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="3"><font class="white"><b>Task Information</b></font></td>
			<tr bgcolor="'.$config['site']['cellpadding'].'">
			<td colspan="3"><font class="white"><b>Task Easy</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="25%"><font class="white"><b>Task Name</b></font></td><td width="15%"><font class="white"><b>Amount</b></font></td><td><font class="white"><b>Reward</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
		<td>Crocodile</td><td>150</td><td>11000 Experience and 2500 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		<td>Dwarfs</td><td>250</td><td>9500 Experience and 1500 Golds</td>		
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
		<td>Ghouls</td><td>350</td><td>55000 Experience and 5000 Golds</td><td><font color="red"><b>NEW</b></font> </td>
		</tr>
        <tr bgcolor="'.$config['site']['lightborder'].'">
		<td>Goblins</td><td>100</td><td>5500 Experience and 750 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Larvas</td><td>250</td><td>10500 Experience And 1100 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Minotaurs</td><td>350</td><td>25000 Experience And 2000 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Rotworms</td><td>200</td><td>15500 Experience And 2000 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Orcs</td><td>150</td><td>5500 Experience And 750 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Pandas</td><td>50</td><td>5500 Experience And 5000 Golds</td>
		</tr>		
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Scarabs</td><td>350</td><td>55000 Experience And 5000 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Tarantulas</td><td>200</td><td>55000 Experience And 5000 Golds</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Trolls</td><td>100</td><td>4500 Experience and 550 Golds</td>
		</tr>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="3"><font class="white"><b>Task Information</b></font></td>
			<tr bgcolor="'.$config['site']['cellpadding'].'">
			<td colspan="3"><font class="white"><b>Task Medium</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="25%"><font class="white"><b>Task Name</b></font></td><td width="15%"><font class="white"><b>Amount</b></font></td><td><font class="white"><b>Reward</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Ancient Scarabs</td><td>350</td><td>250000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Apes</td><td>450</td><td>100000 Experience</td>
		</tr>
				<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Black Knights</td><td>50</td><td>250000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Cyclops</td><td>500</td><td>150000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Demon Skeletons</td><td>200</td><td>120000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Dragons</td><td>500</td><td>350000 Experience</td>
		</tr>
				<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Dwarf Guards</td><td>450</td><td>100000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Fire Elementals</td><td>150</td><td>110000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Giant Spiders</td><td>380</td><td>350000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Heros</td><td>100</td><td>250000 Experience</td>
		</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Humans</td><td>500</td><td>50000 Experience And 15000 Golds</td>
		</tr>
            <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Lizards</td><td>450</td><td>105000 Experience And 15000 Golds</td><td><font color="red"><b>NEW</b></font> </td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Necromancers</td><td>350</td><td>250000 Experience</td>
		</tr>
		     <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Orc Berserkers</td><td>350</td><td>95000 Experience And 5000 Golds</td><td><font color="red"><b>NEW</b></font> </td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Orc Leaders</td><td>350</td><td>105000 Experience And 5000 Golds</td><td><font color="red"><b>NEW</b></font> </td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Orc Warlords</td><td>250</td><td>180000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Terror Birds</td><td>50</td><td>80000 Experience And 10000 Golds</td>
		</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Vampires</td><td>500</td><td>250000 Experience</td><td><font color="red"><b>NEW</b></font> </td>
		</tr>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="3"><font class="white"><b>Task Information</b></font></td>
			<tr bgcolor="'.$config['site']['cellpadding'].'">
			<td colspan="3"><font class="white"><b>Task Hard</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="25%"><font class="white"><b>Task Name</b></font></td><td width="15%"><font class="white"><b>Amount</b></font></td><td><font class="white"><b>Reward</b></font></td>
		</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Behemoths</td><td>300</td><td>950000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Dragon Lords</td><td>550</td><td>850000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Demons</td><td>666</td><td>1900000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Hydras</td><td>450</td><td>850000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Serpent Spawns</td><td>350</td><td>930000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Warlocks</td><td>400</td><td>1100000 Experience</td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="3"><font class="white"><b>Task Information</b></font></td>
			<tr bgcolor="'.$config['site']['cellpadding'].'">
			<td colspan="3"><font class="white"><b>Task Very Hard</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="25%"><font class="white"><b>Task Name</b></font></td><td width="15%"><font class="white"><b>Amount</b></font></td><td><font class="white"><b>Reward</b></font></td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Betrayed Wraiths</td><td>200</td><td>900000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Blightwalkers</td><td>200</td><td>950000 Experience</td>
		</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Dark Torturers</td><td>300</td><td>1250000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Defilers</td><td>250</td><td>950000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Destroyers</td><td>200</td><td>900000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Diabolic Imps</td><td>150</td><td>700000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Hand of Cursed Fates</td><td>150</td><td>1200000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Hellfire Fighters</td><td>250</td><td>1500000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Juggernauts</td><td>200</td><td>1550000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Lost Souls</td><td>250</td><td>920000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Nightmares</td><td>230</td><td>890000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Phantasms</td><td>180</td><td>850000 Experience</td>
		</tr>
		   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Plaguesmiths</td><td>350</td><td>950000 Experience</td>
		</tr>
		    <tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Son of Verminors</td><td>150</td><td>500000 Experience</td>
		</tr>
				   <tr bgcolor="'.$config['site']['lightborder'].'">
		   <td>Undead Dragons</td><td>200</td><td>1300000 Experience</td>
		</tr>
	        </table><br>';
	$main_content .= '</center>';