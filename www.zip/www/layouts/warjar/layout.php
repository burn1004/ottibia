<!DOCTYPE html>
<html ng-app>
	<head>
		<title><?PHP echo $title; ?> ::Alternative Open Tibia Server::</title>
		<?php echo $layout_header; ?>
		<link rel="stylesheet" href="<?PHP echo $layout_name; ?>/css/default.css" type="text/css" />
		<link rel="stylesheet" href="<?PHP echo $layout_name; ?>/css/cms.css" type="text/css" />
		<link rel="stylesheet" href="<?PHP echo $layout_name; ?>/css/main.css" type="text/css" />
		<link rel="stylesheet" href="<?PHP echo $layout_name; ?>/css/news.css" type="text/css" />		
		<link rel="shortcut icon" href="<?PHP echo $layout_name; ?>/images/favicon.gif" />
		
		<!-- Search engine related -->
		<meta name="description" content="SoftCores Retro Tibia, Otserv(Tibia) It is a multiplayer online game (MMORPG). Come play the Best of Old Tibia, with PvP and RPG Truth! -- http://www.softcores.net" />
		<meta name="keywords" content="Tibianic,Tibianus,Classicus,SoftCores Retro Tibia, Servidor de otserv,Servidor de tibia, jogo gratis,old tibia, jogo legal, free online game, free multiplayer game, free online rpg, free mmorpg, mmorpg, mmog, online role playing game, online multiplayer game, internet game, online rpg, rpg,tibia, br, tibiabr, downloads, magias, magic, brasil, tibiabrasil, macetes, tibiarpgbrasil, dicas, tibiagg, mapas, rpg, graphical mud, rpg, game, fantasy, medieval, roleplaying game, mmorpg, massively multiplayer, online game, persistent online game, online world, persistent online world, massively multi-user, massively multi user, multi-user-dungeon, multiuser dungeon, internet game, online spiel, internet spiel, rollenspiel, multiplayer spiel, retro tibia, multiplayer game, free game, kostenloses spiel, free internet game, free online game" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
		
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		
		<!-- Load scripts -->
		<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
		<script type="text/javascript" src="<?PHP echo $layout_name; ?>/js/router.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular.min.js"></script>
		<script type="text/javascript" src="<?PHP echo $layout_name; ?>/js/require.js"></script>
		<script type="text/javascript">

			if(!window.console)
			{
				var console = {
				
					log: function()
					{
						// Prevent stupid browsers from doing stupid things
						// *cough* Internet Explorer *cough*
					}
				};
			}

			function getCookie(c_name)
			{
				var i, x, y, ARRcookies = document.cookie.split(";");

				for(i = 0; i < ARRcookies.length;i++)
				{
					x = ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
					y = ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
					x = x.replace(/^\s+|\s+$/g,"");
					
					if(x == c_name)
					{
						return unescape(y);
					}
				}
			}

			function setCookie(c_name,value,exdays)
			{
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + exdays);
				var c_value = escape(value) + ((exdays == null) ? "" : "; expires="+exdate.toUTCString());
				document.cookie = c_name + "=" + c_value;
			}

			var Config = {
				URL: "http://softcores.net/",			
				image_path: "<?PHP echo $layout_name; ?>/images/",
				CSRF: getCookie('csrf_cookie_name'),
				language: "english",

				UseFusionTooltip: 1,

				Slider: {
					interval: 5000,
					effect: "",
					id: "slider_bg"
				},
				
				voteReminder: 0,

				Theme: {
					next: "Next",
					previous: "Prev"
				}
			};

			var scripts = [
				"<?PHP echo $layout_name; ?>/js/ui.js",
				"<?PHP echo $layout_name; ?>/js/fusioneditor.js",
				"<?PHP echo $layout_name; ?>/js/flux.min.js",
				"<?PHP echo $layout_name; ?>/js/jquery.placeholder.min.js",
				"<?PHP echo $layout_name; ?>/js/jquery.sort.js",
				"<?PHP echo $layout_name; ?>/js/jquery.transit.min.js",
				"<?PHP echo $layout_name; ?>/js/language.js",
				,"<?PHP echo $layout_name; ?>/js/ajax.js"			];

			if(typeof JSON == "undefined")
			{
				scripts.push("<?PHP echo $layout_name; ?>/js/json2.js");
			}

			require(scripts, function()
			{
				$(document).ready(function()
				{
											Language.set("null");
					
					UI.initialize();

											Router.loadedCSS.push("<?PHP echo $layout_name; ?>/css/news.css");
					
											Router.loadedJS.push("<?PHP echo $layout_name; ?>/js/ajax.js");
									});
			});
		</script>

				<script type="text/javascript">






		// Google Analytics
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-54063972-1']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();

		</script>
			</head>
	<body>
		
		<!--[if lte IE 8]>
			<style type="text/css">
				body {
					background-image:url(images/bg.jpg);
					background-position:top center;
				}
			</style>
		<![endif]-->
		<section id="wrapper">
			<div id="popup_bg"></div>

<!-- confirm box -->
<div id="confirm" class="popup">
	<h1 class="popup_question" id="confirm_question"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="confirm_button"></a>
		<a href="javascript:void(0)" class="popup_hide" id="confirm_hide" onClick="UI.hidePopup()">
			Cancel
		</a>
		<div style="clear:both;"></div>
	</div>
</div>


<!-- alert box -->
<div id="alert" class="popup">
	<h1 class="popup_message" id="alert_message"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="alert_button">Okay</a>
		<div style="clear:both;"></div>
	</div>
</div>
<header><a href="https://www.facebook.com/tibiawix" id="hand2" target="_blank"></a></header>
<header><a href="?subtopic=createaccount"" id="hand6" target="_self"></a></header>




			<header id="hand"></header>
                        <header id="hand5"></header>
			<ul id="top_menu">
									<li><a href="?subtopic=latestnews" direct="0">Home</a></li>
									<li><a href="?subtopic=createaccount" direct="0">Register</a></li>
									
									<li><a href="?subtopic=forum" direct="1">Forum</a></li>
									<li><a href="?subtopic=wars" direct="0">Guild Wars</a></li>
									<li><a href="?subtopic=accountmanagement" direct="0">Login</a></li>
							</ul>
							<div id="upek" style="float:right">
									<a href="?subtopic=whoisonline" style="color: white;  style="vertical-align: middle">
                       					Uptime: <?php if($config['status']['serverStatus_online'] == 1) echo $config['status']['serverStatus_uptime']; else echo '0h 0m'; ?><br />
										Players Online: <?php if($config['status']['serverStatus_online'] == 1) echo $config['status']['serverStatus_players']; else echo '0'; ?><br /></a></li>
							</div>	
			<div id="main">
				<aside id="left">
					<article>

						<h1 class="top">Main menu</h1>
						<ul id="left_menu">

															<li><a href="?subtopic=accountmanagement" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Login</a></li>
<li><a href="?subtopic=createaccount" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Create Account</a></li>
<li><a href="?subtopic=lostaccount" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Lost Account?</a></li>
<li><a href="?subtopic=tracker" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Bug Tracker</a></li>
						<h1 class="top">Community</h1>
<li><a href="?subtopic=characters" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Characters</a></li>
<li><a href="?subtopic=whoisonline" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Who Is Online?</a></li>
<li><a href="?subtopic=killstatistics" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Last Death</a></li>
<li><a href="?subtopic=guilds" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Guilds</a></li>
<li><a href="?subtopic=highscores" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Highscores</a></li>
<li><a href="?subtopic=wars" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Guild Wars</a></li>
<li><a href="?subtopic=houses" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Houses</a></li>
<li><a href="?subtopic=powergamers" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Powergamers</a></li>
<li><a href="?subtopic=onlinetime" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Online Times</a></li>
<li><a href="?subtopic=fraggers" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Top Fragers</a></li>
						<h1 class="top">Library</h1>
<li><a href="?subtopic=downloads" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Downloads</a></li>
<li><a href="?subtopic=bans" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Banishement</a></li>
<li><a href="?subtopic=serverinfo" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Server Info</a></li>
<li><a href="?subtopic=tibiarules" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Tibia Rules</a></li>
<li><a href="?subtopic=tasks" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Tasks</a></li>
<li><a href="?subtopic=team" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Support</a></li>
						<h1 class="top">Shop</h1>
<li><a href="?subtopic=buypoints" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Buy Points</font></a></li>
<li><a href="?subtopic=shopsystem" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Shop Offer</font></a></li>
<li><a href="?subtopic=shopsystem&action=show_history" direct="0"><img src="<?PHP echo $layout_name; ?>/images/bullet.png">Trans History</a></li>
					</article>

											
											
											
									</aside>

				<aside id="right">
<?php if ($_GET['subtopic'] == 'latestnews') { ?>
					<section id="slider_bg" >
						<div id="slider">
							<div id="slider_frame">
															<a href="?subtopic=latestnews"><img src="<?PHP echo $layout_name; ?>/images/slides/1.jpg" title=""/></a>
<a href="?subtopic=latestnews"><img src="<?PHP echo $layout_name; ?>/images/slides/2.jpg" title=""/></a>
<a href="?subtopic=latestnews"><img src="<?PHP echo $layout_name; ?>/images/slides/3.jpg" title=""/></a>
<a href="?subtopic=latestnews"><img src="<?PHP echo $layout_name; ?>/images/slides/4.jpg" title=""/></a>
<a href="?subtopic=latestnews"><img src="<?PHP echo $layout_name; ?>/images/slides/5.jpg" title=""/></a>
														
														</div>
						
					</section>
<?php } ?> 
<div class="middle-azuumistrz">
<?php echo $main_content?>

</div>
					
	</article>

</div>

				</aside>

				<div class="clear"></div>

			</div>
			<footer>
				
				<p>&copy; Copyright 2015 SoftCores</p> 
			</footer>
		</section>
	</body>
<script>
function zmienJezyk(cookieName,cookieValue,nDays){
        SetCookie(cookieName,cookieValue,nDays);
        window.location.reload();
} </script>
		<div id="page">
			<div id="logo-art">
				<div id="logo-box">
<div>

</div>
</html>