<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="keywords" content="free online game, free multiplayer game, ots, open tibia server" />
  <meta name="description" content="Tibia is a free massive multiplayer online role playing game (MMORPG)." /><meta name="revisit-after" content="10 days">
<title><?PHP echo $title ?></title>
<script>var start_time = new Date().getTime();</script>
<link rel="shortcut icon" type="image/x-icon" href="/images/favicon.ico" />
<link rel="stylesheet" type="text/css" href="<?PHP echo $layout_name; ?>/css/main.css?ver=1.3.4" />
<link rel="stylesheet" type="text/css" href="<?PHP echo $layout_name; ?>/css/colorbox.css?ver=1.0" />
<link rel="stylesheet" type="text/css" href="<?PHP echo $layout_name; ?>/css/nanoscroller.css?ver=1.0" />
<link rel="stylesheet" type="text/css" href="<?PHP echo $layout_name; ?>/css/font-awesome.css?ver=1.0" />
</head>
<body>

<div id="stripe"></div>

<div id="site-wrapper">
<nav id="top">
<ul>
<a href="?subtopic=latestnews"><li>NEWS</li></a>
<li class="menu_sep"></li>
<a href="?subtopic=forum"><li>FORUMS</li></a>
<li class="menu_sep"></li>
<a href="?subtopic=buypoints"><li>SHOP</li></a>
<li class="menu_sep"></li>
<a href="?subtopic=highscores"><li>RANKING</li></a>
</ul>
</nav>
<div id="content">
<div id="content_left_wrapper">
<section class="left">
<div class="content_title_LEFT">&nbsp;<i class="icon-user"></i>&nbsp;&nbsp;Membership</div>
<?php if($logged) {
?>
<nav class="left">
<ul>
<li><a href="?subtopic=accountmanagement">Manage Account</a></li>
<li><a href="?subtopic=accountmanagement&action=createcharacter">Create Character</a></li>
<li><a href="?subtopic=accountmanagement&action=logout">Logout</a></li>
</ul>
</nav>

<?php
}
else {?>
<form id="login-box" action="?subtopic=accountmanagement" method="POST" >
<ul>
<li>
<span class="capital">ACCOUNT USERNAME</span>
<input type="text" name="account_login" id="login_userinput" style="width:170px" maxlength="16" />
</li>
<li>
<span class="capital">ACCOUNT PASSWORD</span>
<input type="password" name="password_login" id="login_passinput" style="width:170px" maxlength="16" />
</li>
<li style="overflow:hidden;">
<button class="small_button60 block fleft" type="submit" name="login_submit_1" id="login_submit_1" ><i class="icon-signin"></i> LOG IN</button>
<div class="fleft loginoptions">
<a href="?subtopic=createaccount">Create Account</a><br />
<a href="?subtopic=lostaccount">Lost Password ?</a>
</div>
</li>
</form>
<?php }?>
</section>
<section class="left">
<div class="content_title_LEFT">&nbsp;<i class="icon-list-ul"></i>&nbsp;&nbsp;Main Menu</div>
<nav class="left">
<ul>
<li><a href="?subtopic=latestnews">News</a></li>
<li><a href="?subtopic=forum">Forum</a></li>
<li><a href="?subtopic=serverinfo">Server Info</a></li>
<li><a href="?subtopic=accountmanagement">Account</a></li>
<li><a href="?subtopic=lostaccount">Lost account?</a></li>
<li><a href="?subtopic=whoisonline">Who is Online</a></li>
<li><a href="?subtopic=records">Online Records</a></li>
<li><a href="?subtopic=characters">Search Character</a></li>
<li><a href="?subtopic=highscores">Ranking</a></li>
<li><a href="?subtopic=wars">Wars</a></li>
<li><a href="?subtopic=guilds">Guilds</a></li>
<li><a href="?subtopic=team">Support</a></li>
<li><a href="?subtopic=buypoints">Buy Points</a></li>
<li><a href="?subtopic=shopsystem">Shop Offer</a></li>
</ul>
</nav>
</section>
</div>
<div id="content_center_wrapper_extended">
<section class="center">
<header><?PHP echo ucwords(str_replace('_', ' ', strtolower($subtopic))); ?></header>
<?php echo $main_content;?>
</section>
</div>
</div>
<footer>
<div id="footer_pages">
<a href="?subtopic=latestnews">NEWS</a> |
<a href="?subtopic=buypoints">DONATE</a> |
<a href="?subtopic=shopsystem">SHOP OFFER</a> |
<a href="?subtopic=team">SUPPORT</a> |
<a href="?subtopic=forum">FORUM</a> |
<a href="?subtopic=highscores">RANKING</a>
</div>
<p>WarOTS.pl&trade; Copyright &copy; 2015-2016. All rights reserved.</p>
<p></p>
</footer>
</div>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script>var SF = {};
$(function() { SF.bindAutoClose = function(time) { $(document).bind('cbox_complete', function(){ setTimeout($.colorbox.close, time); infoPopupClose = 0; }); } SF.popUp = function(id) { $.colorbox({ speed:350, width:"500px", top:"200px", inline:true, href:"#"+id }); } $("body > :not(#colorbox)").click(function() { if ($("#colorbox").css("display") == "block") { $.colorbox.close(); } });
});</script>
<script>$(function() { var height = $(window).height(); $('.scroller').css('height', height); $('.scroller').css('position', 'relative'); $('.scroller').nanoScroller({ contentClass: 'scroller-content'}); $(window).resize(function() { height = $(window).height(); $('.scroller').css('height', height); $('.scroller').nanoScroller({ contentClass: 'scroller-content'}); }); });</script>
</body>
</html>
